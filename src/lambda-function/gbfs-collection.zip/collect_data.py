import json
import urllib.request

def collect_vehicles(vehicles_url, vehicle_type):

    r = urllib.request.urlopen(vehicles_url)
    vehicles_data = json.loads(r.read().decode('utf-8'))
    
    timestamp = vehicles_data['last_updated']
    
    vehicles_data = json.dumps(vehicles_data, ensure_ascii=False)  
    vehicles_file = f'{vehicle_type}/{vehicle_type}_' + str(timestamp) + '.json'
    
    return vehicles_data, vehicles_file

def collect_stations(stations_url):

    r = urllib.request.urlopen(stations_url)

    stations_data = json.loads(r.read().decode('utf-8'))
    timestamp = stations_data['last_updated']
    stations_data = json.dumps(stations_data, ensure_ascii=False)

    stations_file = 'stations/stations_' + str(timestamp) + '.json'
    
    return stations_data, stations_file