import json
import boto3
import botocore
from collect_data import collect_vehicles

print('Loading function')
def handler(event, context):
    
    bucket_name = 'pvd-lime-scooters'
    scooters_status = 'https://data.lime.bike/api/partners/v1/gbfs/providence/free_bike_status.json'
    #station_status = 'https://data.lime.bike/api/partners/v1/gbfs/providence/station_status'

    scooters_data, scooters_file = collect_vehicles(scooters_status, 'scooters')
    #stations_data, stations_file = collect_stations(station_status)

    # S3 Connect
    s3 = boto3.resource(
        's3',
        config=botocore.client.Config(signature_version='s3v4')
    )

    # Uploaded File
    #s3.Bucket(bucket_name).put_object(Key=stations_file, Body=stations_data)
    s3.Bucket(bucket_name).put_object(Key=scooters_file, Body=scooters_data)